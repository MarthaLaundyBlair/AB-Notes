package com.ab.models;

public class FullTimeStudent extends Student {
	

}
