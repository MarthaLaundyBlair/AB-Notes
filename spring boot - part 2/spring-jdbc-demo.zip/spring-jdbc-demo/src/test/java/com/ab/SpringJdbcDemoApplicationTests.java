package com.ab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
